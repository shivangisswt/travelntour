<?php

class byt_location extends byt_entity
{
    public function __construct( $entity ) {
		parent::__construct( $entity, 'location' );
    }
	
}